so if u want to run/test my program
u need 2 computers wind windows (it can be 1 pc, but
program was created to use on 2 pc or more)
then on first pc run console.exe (this program
navigate all these programs in the folder)

on another computer run program mailfinder.exe OR
nonmailfinder.exe
(these are the same program, but first has windows, 2nd
dont have window)

in console.exe type start and enjoy


sorry for my english,
im 13yo poland guy btw
its my first 'better' program

(u can check my website flatearth.pl or piggers.net (https://)